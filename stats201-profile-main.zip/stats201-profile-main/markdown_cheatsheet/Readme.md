**References**
- https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet#code
- https://github.com/sunshineluyao/Readme-Cheatsheet
